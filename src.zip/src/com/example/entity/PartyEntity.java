package com.example.entity;

public class PartyEntity {

	private Integer ID;
	private String NAME;
	private Integer CONTACT_NO;

	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public Integer getCONTACT_NO() {
		return CONTACT_NO;
	}

	public void setCONTACT_NO(Integer cONTACT_NO) {
		CONTACT_NO = cONTACT_NO;
	}

}
